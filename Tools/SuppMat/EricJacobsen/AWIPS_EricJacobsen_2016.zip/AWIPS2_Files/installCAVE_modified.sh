#!/bin/bash -f
#
# installCAVE.sh - a short script to manage the yum repo setup and install
#                  of AWIPS II CAVE
#
# 10/15         mjames@ucar.edu         Creation
#

#
##  Download awips2.repo from the Unidata web server
# 

if [ ! -f /etc/yum.repos.d/awips2.repo ]; then
  echo ''
  echo 'Downloading awips2repo yum file to /etc/yum.repos.d/awips2.repo'
  echo ''
  wget -O /etc/yum.repos.d/awips2.repo http://www.unidata.ucar.edu/software/awips2/doc/awips2.repo
  echo "Running 'yum clean all'"
  yum clean all
  echo ''
fi

##
## If CAVE is not installed them make sure /awips2/cave/
## and /awips2/alertviz/ are removed before installing.
##

##########################################################
####Begin Changes to Unidata installCave.sh##########
# These changes incorporate system configuration steps from http://www.unidata.ucar.edu/software/awips2/doc/install-cave.html so that this modified installCAVE.sh script can perform all needed steps to retrieve, configure, and install CAVE

##disable selinux##
sed -i 's\SELINUX=enforcing\SELINUX=disabled\g' /etc/sysconfig/selinux

##edit limits.conf##
echo "awips soft nproc 65536" >> /etc/security/limits.conf
echo "awips soft nofile 65536" >> /etc/security/limits.conf

##update groups and users##
echo "Adding Standard Awips Group and User Accounts"
/usr/sbin/groupadd -g 12345 awips
sleep 1
/usr/sbin/groupadd -g 200 fxalpha
sleep 1
/usr/sbin/useradd -g fxalpha -G awips -p saY.yTZshXYeE -s /bin/bash -u 12345 awips
sleep 1
/usr/sbin/useradd -g fxalpha -G awips -p sampyK2QsVhEc -s /bin/tcsh -u 1100 fxa
sleep 1

# check that /awips2 exists, if not, create it
if [ ! -d /awips2 ]; then
  mkdir -p /awips2
  fi
/bin/chown -R awips:fxalpha /awips2

##Configure iptables##
# Adds rules to second to last line (before COMMIT)
sed -i '$i-A INPUT -p tcp -m tcp --dport 5672 -j ACCEPT' /etc/sysconfig/iptables
sed -i '$i-A INPUT -p tcp -m tcp --dport 9581 -j ACCEPT' /etc/sysconfig/iptables
sed -i '$i-A INPUT -p tcp -m tcp --dport 9582 -j ACCEPT' /etc/sysconfig/iptables

# Restart iptables to make change
service iptables restart

####End Changes to Unidata installCave.sh############
#########################################################

if [[ $(rpm -qa | grep awips2-cave) ]]; then
  echo "found CAVE RPMs installed"
else
  echo "  CAVE RPMs not installled"
  echo ""
  echo "  cleaning up /awips2/cave/, /awips2/alertviz/"
  rm -rf /awips2/cave/ /awips2/alertviz/
fi

echo ''
echo "Running 'yum groupinstall awips2-cave'"
echo ''
yum groupinstall awips2-cave -y 2>&1 | tee -a /tmp/cave-install.log

if getent passwd awips &>/dev/null; then
  echo ''
  echo "Setting permissions to user awips:fxalpha"
  /bin/chown -R awips:fxalpha /awips2/cave /awips2/alertviz
else
  echo ''
  echo "--- user awips does not exist"
  echo "--- you should set owner/group permissions for /awips2/cave and /awips2/alertviz:"
  echo "tried to run 'chown -R awips:fxalpha /awips2/cave /awips2/alertviz'"
fi
echo ""
echo "Done..."
echo ""
echo "  to run cave:"
echo ""
echo "  /awips2/cave/cave.sh"
exit
